﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp5;
using static WindowsFormsApp5.Form2;



namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        private List<Hamburger> menu;
        private List<OrderItem> orderList;
        private List<string> selectedSideOptions;
        private List<string> selectedDrinkOptions;

        public Form1()
        {
            InitializeComponent();
            InitializeMenu();
            orderList = new List<OrderItem>();
        }
        private void InitializeMenu()
        {
            // 햄버거 메뉴 초기화
            menu = new List<Hamburger>
            {
                new Hamburger("Cheeseburger", 5000, new List<string> { "French Fries" }, new List<string> { "Coke" }),
                new Hamburger("Double Cheeseburger", 7000, new List<string> { "Curly Fries"}, new List<string> { "Lemonade" }),
                new Hamburger("Bacon Burger", 6000, new List<string> { "Chicken Nuggets" }, new List<string> { "Sprite" }),
                new Hamburger("Chicken Burger", 5500, new List<string> { "Onion Rings" }, new List<string> { "Sprite" })
            };

            // 콤보 박스에 햄버거 메뉴 추가
            foreach (var hamburger in menu)
            {
                comboBoxMenu.Items.Add(hamburger.Name);
            }

            comboBoxMenu.SelectedIndex = 0; // 기본 선택 항목 설정
        }


        private void btnAddToOrder_Click(object sender, EventArgs e)
        {
            // 주문 목록에 항목 추가
            string selectedItem = comboBoxMenu.SelectedItem.ToString();
            int quantity = (int)numericUpDownQuantity.Value;

            // 선택한 햄버거 찾기
            Hamburger selectedHamburger = menu.Find(h => h.Name == selectedItem);

            if (selectedHamburger != null)
            {
                // 주문 목록에 추가
                OrderItem orderItem = new OrderItem(selectedHamburger, quantity, selectedSideOptions, selectedDrinkOptions);
                orderList.Add(orderItem);

                // 주문 목록 표시
                UpdateOrderList();
            }
            else
            {
                MessageBox.Show("유효한 햄버거를 선택하세요.");
            }
        }

        private void UpdateOrderList()
        {
            // 주문 목록 표시
            listBoxOrder.Items.Clear();
            listBoxOrder2.Items.Clear();
            listBoxOrder3.Items.Clear();
            int total = 0;

            foreach (var orderItem in orderList)
            {
                listBoxOrder.Items.Add($"{orderItem.Hamburger.Name}");
                listBoxOrder2.Items.Add($"{orderItem.Quantity}개");
                listBoxOrder3.Items.Add($"{orderItem.TotalPrice}원");

                total += orderItem.TotalPrice;
            }

            textBoxTotal.Text = total.ToString();

            // 디버깅 정보 추가
            Console.WriteLine("UpdateOrderList 호출됨.");
            Console.WriteLine($"orderList.Count: {orderList.Count}");
            Console.WriteLine($"listBoxOrder.Items.Count: {listBoxOrder.Items.Count}");
        }


        // 햄버거 클래스 정의
        public class Hamburger
        {
            public string Name { get; }
            public int Price { get; }
            public List<string> SideOptions { get; set; }
            public List<string> DrinkOptions { get; set; }

            public Hamburger(string name, int price, List<string> sideOptions, List<string> drinkOptions)
            {
                Name = name;
                Price = price;
                SideOptions = sideOptions;
                DrinkOptions = drinkOptions;
            }
        }

        // 주문 항목 클래스 정의
        public class OrderItem
        {
            public Hamburger Hamburger { get; }
            public List<string> SideOptions { get; set; }
            public List<string> DrinkOptions { get; set; }
            public int Quantity { get; set; }
            public int TotalPrice => Quantity * Hamburger.Price;

            public OrderItem(Hamburger hamburger, int quantity, List<string> sideOptions, List<string> drinkOptions)
            {
                Hamburger = hamburger;
                Quantity = quantity;
                SideOptions = sideOptions ?? new List<string>();
                DrinkOptions = drinkOptions ?? new List<string>();
            }

            public override string ToString()
            {
                string sideOptionsString = SideOptions.Any() ? $", Side Options: {string.Join(", ", SideOptions)}" : "";
                string drinkOptionsString = DrinkOptions.Any() ? $", Drink Options: {string.Join(", ", DrinkOptions)}" : "";

                return $"{Hamburger?.Name}, Quantity: {Quantity}, TotalPrice: {TotalPrice}, {sideOptionsString}, {drinkOptionsString}";
            }

            // 추가: Hamburger 객체에 대한 변경 메서드
            public void UpdateHamburgerOptions(List<string> newSideOptions, List<string> newDrinkOptions)
            {
                // Hamburger 객체의 옵션 업데이트
                Hamburger.SideOptions = newSideOptions;
                Hamburger.DrinkOptions = newDrinkOptions;
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            if (listBoxOrder2.SelectedIndex != -1)
            {
                // 선택된 주문 항목 가져오기
                OrderItem selectedOrderItem = orderList[listBoxOrder2.SelectedIndex];

                // 선택된 주문 항목의 수량 변경
                int newQuantity = (int)numericUpDownOrderQuantity.Value;
                selectedOrderItem.Quantity = newQuantity;

                // Check if the new quantity is greater than 0
                if (newQuantity > 0)
                {
                    // 주문 목록 업데이트
                    UpdateOrderList();
                }
                else
                {
                    // If the new quantity is 0, remove the item from the order list
                    orderList.Remove(selectedOrderItem);

                    // 주문 목록 업데이트
                    UpdateOrderList();
                }
            }
            else
            {
                MessageBox.Show("수정할 주문을 선택하세요.");
            }
        }

        private void DELETE_Click(object sender, EventArgs e)
        {
            if (listBoxOrder2.SelectedIndex != -1)
            {
                // 선택된 주문 항목 가져오기
                OrderItem selectedOrderItem = orderList[listBoxOrder2.SelectedIndex];

                // 주문 항목 제거
                orderList.Remove(selectedOrderItem);

                // 주문 목록 업데이트
                UpdateOrderList();
            }
            else
            {
                MessageBox.Show("삭제할 주문을 선택하세요.");
            }
        }

        private void listBoxOrder_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listBoxOrder.SelectedIndex != -1)
            {
                OrderItem selectedOrderItem = orderList[listBoxOrder.SelectedIndex];

                // OrderItemDetailsForm을 엽니다.
                using (Form2 detailsForm = new Form2(listBoxOrder, orderList, selectedOrderItem))
                {
                    if (detailsForm.ShowDialog() == DialogResult.OK)
                    {
                        // 수정된 내용으로 주문 목록을 업데이트합니다.
                        UpdateOrderList();
                    }
                }
            }
        }




    }
}