﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp4;
using static WindowsFormsApp4.Form1;

namespace WindowsFormsApp5
{
    public partial class Form2 : Form
    {
        private ListBox listBoxOrderForm2;
        private List<OrderItem> orderListForm2;
        private OrderItem orderItem;

        public List<string> SelectedSideOptions { get; private set; }
        public List<string> SelectedDrinkOptions { get; private set; }


        public Form2(ListBox listBoxOrder, List<OrderItem> orderList, OrderItem selectedOrderItem)
        {
            InitializeComponent();

            listBoxOrderForm2 = listBoxOrder;
            orderListForm2 = orderList;
            orderItem = selectedOrderItem;

            MessageBox.Show($"Received OrderItem: {orderItem}");

            if (orderItem.Hamburger != null)
            {
                SelectedSideOptions = new List<string>(orderItem.Hamburger.SideOptions); // 수정된 부분
                SelectedDrinkOptions = new List<string>(orderItem.Hamburger.DrinkOptions); // 수정된 부분

                // 기존 주문 정보를 기반으로 선택된 옵션을 설정
                SetSelectedOptions();
            }
            else
            {
                MessageBox.Show("주문 항목에 햄버거 정보가 없습니다.");
                this.Close();
            }
        }

        private void SetSelectedOptions()
        {
            // 기존 주문 정보를 기반으로 선택된 사이드 옵션을 설정
            foreach (RadioButton radioButton in flowLayoutPanelSides.Controls)
            {
                radioButton.Checked = SelectedSideOptions.Contains(radioButton.Text);
            }

            // 기존 주문 정보를 기반으로 선택된 음료 옵션을 설정
            foreach (RadioButton radioButton in flowLayoutPanelDrinks.Controls)
            {
                radioButton.Checked = SelectedDrinkOptions.Contains(radioButton.Text);
            }
        }





        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            // 라디오 버튼이 변경될 때 주문 항목의 옵션을 업데이트
            RadioButton radioButton = sender as RadioButton;

            if (radioButton != null)
            {
                if (flowLayoutPanelSides.Controls.Contains(radioButton))
                {
                    // 사이드 옵션 업데이트
                    UpdateOptionList(orderItem.SideOptions, radioButton.Text, radioButton.Checked);
                }
                else if (flowLayoutPanelDrinks.Controls.Contains(radioButton))
                {
                    // 음료 옵션 업데이트
                    UpdateOptionList(orderItem.DrinkOptions, radioButton.Text, radioButton.Checked);
                }
            }
        }

        private void UpdateOptionList(List<string> optionsList, string option, bool isChecked)
        {
            if (isChecked)
            {
                // 체크된 경우 옵션을 추가
                optionsList.Add(option);
            }
            else
            {
                // 체크가 해제된 경우 옵션을 제거
                optionsList.Remove(option);
            }
        }

        // OK 버튼 클릭 이벤트를 처리
        private void btnOK_Click(object sender, EventArgs e)
        {
            // 현재 라디오 버튼 상태를 기반으로 SelectedSideOptions 및 SelectedDrinkOptions를 업데이트합니다.
            UpdateSelectedOptions();

            // 선택된 옵션을 주문 항목에 반영합니다.
            orderItem.SideOptions = SelectedSideOptions;
            orderItem.DrinkOptions = SelectedDrinkOptions;

            // 추가: Hamburger 객체의 변경 내용을 업데이트합니다.
            orderItem.UpdateHamburgerOptions(orderItem.SideOptions, orderItem.DrinkOptions);

            // Form1의 주문 목록을 수정된 orderItem으로 업데이트합니다.
            int selectedIndex = listBoxOrderForm2.SelectedIndex;
            orderListForm2[selectedIndex] = orderItem;

            // Form1의 주문 목록을 업데이트합니다.
            listBoxOrderForm2.Items[selectedIndex] = $"{orderItem.Hamburger.Name} - {orderItem.Quantity}개 - {orderItem.TotalPrice}원";

            DialogResult = DialogResult.OK;
            Close();
        }


        private void UpdateSelectedOptions()
        {
            // Update SelectedSideOptions based on the current state of radio buttons for sides
            SelectedSideOptions.Clear();
            foreach (RadioButton radioButton in flowLayoutPanelSides.Controls)
            {
                if (radioButton.Checked)
                {
                    SelectedSideOptions.Add(radioButton.Text);
                }
            }

            // Update SelectedDrinkOptions based on the current state of radio buttons for drinks
            SelectedDrinkOptions.Clear();
            foreach (RadioButton radioButton in flowLayoutPanelDrinks.Controls)
            {
                if (radioButton.Checked)
                {
                    SelectedDrinkOptions.Add(radioButton.Text);
                }
            }

            // 디버깅 메시지 추가
            MessageBox.Show($"SelectedSideOptions: {string.Join(", ", SelectedSideOptions)}");
            MessageBox.Show($"SelectedDrinkOptions: {string.Join(", ", SelectedDrinkOptions)}");
        }

        // 취소 버튼 클릭 이벤트를 처리
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }


    }
}