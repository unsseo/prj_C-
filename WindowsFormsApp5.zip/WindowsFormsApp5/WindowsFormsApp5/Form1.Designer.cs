﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxMenu = new System.Windows.Forms.ComboBox();
            this.btnAddToOrder = new System.Windows.Forms.Button();
            this.numericUpDownQuantity = new System.Windows.Forms.NumericUpDown();
            this.listBoxOrder = new System.Windows.Forms.ListBox();
            this.listBoxOrder2 = new System.Windows.Forms.ListBox();
            this.listBoxOrder3 = new System.Windows.Forms.ListBox();
            this.numericUpDownOrderQuantity = new System.Windows.Forms.NumericUpDown();
            this.btnChange = new System.Windows.Forms.Button();
            this.textBoxTotal = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DELETE = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOrderQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxMenu
            // 
            this.comboBoxMenu.FormattingEnabled = true;
            this.comboBoxMenu.Location = new System.Drawing.Point(40, 12);
            this.comboBoxMenu.Name = "comboBoxMenu";
            this.comboBoxMenu.Size = new System.Drawing.Size(203, 23);
            this.comboBoxMenu.TabIndex = 0;
            // 
            // btnAddToOrder
            // 
            this.btnAddToOrder.Location = new System.Drawing.Point(428, 10);
            this.btnAddToOrder.Name = "btnAddToOrder";
            this.btnAddToOrder.Size = new System.Drawing.Size(141, 39);
            this.btnAddToOrder.TabIndex = 1;
            this.btnAddToOrder.Text = "btnAddToOrder";
            this.btnAddToOrder.UseVisualStyleBackColor = true;
            this.btnAddToOrder.Click += new System.EventHandler(this.btnAddToOrder_Click);
            // 
            // numericUpDownQuantity
            // 
            this.numericUpDownQuantity.Location = new System.Drawing.Point(265, 10);
            this.numericUpDownQuantity.Name = "numericUpDownQuantity";
            this.numericUpDownQuantity.Size = new System.Drawing.Size(125, 25);
            this.numericUpDownQuantity.TabIndex = 2;
            // 
            // listBoxOrder
            // 
            this.listBoxOrder.FormattingEnabled = true;
            this.listBoxOrder.ItemHeight = 15;
            this.listBoxOrder.Location = new System.Drawing.Point(30, 180);
            this.listBoxOrder.Name = "listBoxOrder";
            this.listBoxOrder.Size = new System.Drawing.Size(240, 94);
            this.listBoxOrder.TabIndex = 3;
            this.listBoxOrder.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBoxOrder_MouseDoubleClick);
            // 
            // listBoxOrder2
            // 
            this.listBoxOrder2.FormattingEnabled = true;
            this.listBoxOrder2.ItemHeight = 15;
            this.listBoxOrder2.Location = new System.Drawing.Point(293, 180);
            this.listBoxOrder2.Name = "listBoxOrder2";
            this.listBoxOrder2.Size = new System.Drawing.Size(240, 94);
            this.listBoxOrder2.TabIndex = 4;
            // 
            // listBoxOrder3
            // 
            this.listBoxOrder3.FormattingEnabled = true;
            this.listBoxOrder3.ItemHeight = 15;
            this.listBoxOrder3.Location = new System.Drawing.Point(714, 180);
            this.listBoxOrder3.Name = "listBoxOrder3";
            this.listBoxOrder3.Size = new System.Drawing.Size(240, 94);
            this.listBoxOrder3.TabIndex = 5;
            // 
            // numericUpDownOrderQuantity
            // 
            this.numericUpDownOrderQuantity.Location = new System.Drawing.Point(546, 180);
            this.numericUpDownOrderQuantity.Name = "numericUpDownOrderQuantity";
            this.numericUpDownOrderQuantity.Size = new System.Drawing.Size(125, 25);
            this.numericUpDownOrderQuantity.TabIndex = 6;
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(546, 235);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(141, 39);
            this.btnChange.TabIndex = 7;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // textBoxTotal
            // 
            this.textBoxTotal.Location = new System.Drawing.Point(724, 351);
            this.textBoxTotal.Name = "textBoxTotal";
            this.textBoxTotal.Size = new System.Drawing.Size(228, 25);
            this.textBoxTotal.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(721, 323);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "합계";
            // 
            // DELETE
            // 
            this.DELETE.Location = new System.Drawing.Point(562, 282);
            this.DELETE.Name = "DELETE";
            this.DELETE.Size = new System.Drawing.Size(109, 56);
            this.DELETE.TabIndex = 10;
            this.DELETE.Text = "DELETE";
            this.DELETE.UseVisualStyleBackColor = true;
            this.DELETE.Click += new System.EventHandler(this.DELETE_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 450);
            this.Controls.Add(this.DELETE);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxTotal);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.numericUpDownOrderQuantity);
            this.Controls.Add(this.listBoxOrder3);
            this.Controls.Add(this.listBoxOrder2);
            this.Controls.Add(this.listBoxOrder);
            this.Controls.Add(this.numericUpDownQuantity);
            this.Controls.Add(this.btnAddToOrder);
            this.Controls.Add(this.comboBoxMenu);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOrderQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxMenu;
        private System.Windows.Forms.Button btnAddToOrder;
        private System.Windows.Forms.NumericUpDown numericUpDownQuantity;
        private System.Windows.Forms.ListBox listBoxOrder;
        private System.Windows.Forms.ListBox listBoxOrder2;
        private System.Windows.Forms.ListBox listBoxOrder3;
        private System.Windows.Forms.NumericUpDown numericUpDownOrderQuantity;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.TextBox textBoxTotal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DELETE;
    }
}

